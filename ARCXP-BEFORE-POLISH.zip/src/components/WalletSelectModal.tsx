import { useEffect, useMemo, useState } from "react";
import { Loader2, Wallet, X, ExternalLink } from "lucide-react";
import { listWallets, type WalletOption } from "@/lib/wallet-providers";

export function WalletSelectModal({
  open,
  onClose,
  onSelect,
  title = "Connect a wallet",
  subtitle = "Choose a wallet to sign in to ARC XP on ARC Testnet.",
}: {
  open: boolean;
  onClose: () => void;
  onSelect: (wallet: WalletOption) => Promise<void>;
  title?: string;
  subtitle?: string;
}) {
  const [busyId, setBusyId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [tick, setTick] = useState(0);

  // Re-list after mount so EIP-6963 announcements have time to arrive
  useEffect(() => {
    if (!open) return;
    setError(null);
    const t = setTimeout(() => setTick((n) => n + 1), 150);
    return () => clearTimeout(t);
  }, [open]);

  // Escape to close + body scroll lock
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    document.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [open, onClose]);

  const wallets = useMemo(() => listWallets(), [open, tick]);

  if (!open) return null;

  const handle = async (w: WalletOption) => {
    setBusyId(w.id);
    setError(null);
    try {
      await onSelect(w);
      onClose();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Connection failed");
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto animate-fade-in">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className="relative glass-strong rounded-t-2xl sm:rounded-2xl w-full max-w-md p-5 sm:p-6 border border-white/10 max-h-[92vh] overflow-y-auto my-0 sm:my-auto animate-scale-in"
      >
        <button
          onClick={onClose}
          className="absolute top-3 right-3 p-2.5 rounded-lg hover:bg-white/10 active:scale-95 transition-all duration-200"
          aria-label="Close"
        >
          <X className="h-4 w-4" />
        </button>
        <div className="flex items-center gap-3 mb-1">
          <Wallet className="h-5 w-5 text-brand-cyan" />
          <h2 className="text-lg font-bold">{title}</h2>
        </div>
        <p className="text-xs text-muted-foreground mb-5">{subtitle}</p>

        <div className="flex flex-col gap-2">
          {wallets.map((w) => (
            <button
              key={w.id}
              onClick={() => (w.installed ? handle(w) : window.open(w.installUrl, "_blank"))}
              disabled={busyId !== null}
              className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl glass hover:bg-white/10 hover:border-brand-cyan/30 border border-white/5 transition-all duration-200 active:scale-[0.98] disabled:opacity-50 text-left"
            >
              {w.icon ? (
                <img src={w.icon} alt="" className="h-7 w-7 rounded-md" />
              ) : (
                <div className="h-7 w-7 rounded-md gradient-bg flex items-center justify-center">
                  <Wallet className="h-3.5 w-3.5 text-primary-foreground" />
                </div>
              )}
              <div className="flex-1 min-w-0">
                <div className="text-sm font-semibold">{w.name}</div>
                <div className="text-[10px] text-muted-foreground uppercase tracking-wider">
                  {w.installed ? (w.kind === "walletconnect" ? "Scan QR" : "Detected") : "Not installed"}
                </div>
              </div>
              {busyId === w.id ? (
                <Loader2 className="h-4 w-4 animate-spin text-brand-cyan" />
              ) : !w.installed ? (
                <ExternalLink className="h-3.5 w-3.5 opacity-60" />
              ) : null}
            </button>
          ))}
        </div>

        {error && (
          <p className="text-xs text-red-400 mt-4 break-words">{error}</p>
        )}
        <p className="text-[10px] text-muted-foreground mt-5 text-center uppercase tracking-[0.25em]">
          ARC Testnet · Chain ID 5042002
        </p>
      </div>
    </div>
  );
}