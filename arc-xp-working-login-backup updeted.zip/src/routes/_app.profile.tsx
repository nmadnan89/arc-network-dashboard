import { createFileRoute } from "@tanstack/react-router";
import { Calendar, Trophy, Award, Flame } from "lucide-react";
import { currentUser, contributionHistory, recentActivity, badges } from "@/lib/demo-data";

export const Route = createFileRoute("/_app/profile")({
  head: () => ({ meta: [{ title: "Profile — ARC XP" }] }),
  component: Profile,
});

function Profile() {
  const max = Math.max(...contributionHistory.map((c) => c.points));
  const unlocked = badges.filter((b) => b.unlocked).slice(0, 6);

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="glass rounded-2xl p-5 sm:p-8 relative overflow-hidden">
        <div className="absolute inset-0 opacity-40 pointer-events-none" style={{ background: "var(--gradient-glow)" }} />
        <div className="relative flex flex-col sm:flex-row items-center sm:items-end gap-4 sm:gap-6">
          <img src={currentUser.avatar} alt={currentUser.username} className="h-24 w-24 sm:h-28 sm:w-28 rounded-2xl ring-2 ring-white/20 glow" />
          <div className="flex-1 text-center sm:text-left min-w-0">
            <h1 className="text-3xl sm:text-4xl font-bold break-words"><span className="gradient-text">{currentUser.username}</span></h1>
            <p className="text-muted-foreground mt-1">{currentUser.handle} · Joined {currentUser.joined}</p>
          </div>
          <button className="gradient-bg text-primary-foreground font-semibold px-5 py-2.5 rounded-xl glow hover:opacity-90 transition w-full sm:w-auto">Edit Profile</button>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Total Points", value: currentUser.totalPoints.toLocaleString(), icon: Trophy },
          { label: "Global Rank", value: `#${currentUser.rank}`, icon: Trophy },
          { label: "Badges", value: currentUser.badgesEarned, icon: Award },
          { label: "Streak", value: `${currentUser.streak}d`, icon: Flame },
        ].map((s) => (
          <div key={s.label} className="glass rounded-2xl p-5">
            <s.icon className="h-5 w-5 text-brand-cyan mb-2" />
            <div className="text-2xl font-bold">{s.value}</div>
            <div className="text-xs text-muted-foreground">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <div className="glass rounded-2xl p-6">
          <h2 className="text-lg font-semibold mb-1">Contribution History</h2>
          <p className="text-xs text-muted-foreground mb-6">Points earned over the last 6 months</p>
          <div className="flex items-end justify-between gap-2 h-48">
            {contributionHistory.map((c, i) => (
              <div key={c.month} className="flex-1 flex flex-col items-center gap-1.5 h-full justify-end min-w-0">
                <div className="text-[10px] sm:text-xs text-muted-foreground">{c.points}</div>
                <div
                  className="w-full rounded-t-lg gradient-bg glow-sm animate-scale-in"
                  style={{ height: `calc(${(c.points / max) * 100}% - 36px)`, minHeight: "20px", animationDelay: `${i * 80}ms` }}
                />
                <div className="text-[10px] sm:text-xs text-muted-foreground">{c.month}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="glass rounded-2xl p-6">
          <h2 className="text-lg font-semibold mb-4">Activity Feed</h2>
          <div className="space-y-4">
            {recentActivity.map((a) => (
              <div key={a.id} className="flex items-center gap-3 pb-3 border-b border-white/5 last:border-0">
                <div className="h-9 w-9 rounded-xl glass-strong flex items-center justify-center">
                  <Calendar className="h-4 w-4 text-brand-cyan" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium truncate">{a.action}</div>
                  <div className="text-xs text-muted-foreground truncate">{a.detail} · {a.time}</div>
                </div>
                <div className="text-sm font-semibold gradient-text">+{a.points}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="glass rounded-2xl p-6">
        <h2 className="text-lg font-semibold mb-4">Badge Showcase</h2>
        <div className="grid grid-cols-3 sm:grid-cols-6 gap-4">
          {unlocked.map((b) => (
            <div key={b.id} className="text-center">
              <div className="h-14 w-14 mx-auto rounded-xl gradient-bg flex items-center justify-center text-2xl glow">{b.icon}</div>
              <div className="text-xs mt-2 truncate">{b.name}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}