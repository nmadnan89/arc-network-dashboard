import {
  collection,
  doc,
  getDoc,
  getDocs,
  limit,
  onSnapshot,
  query,
  runTransaction,
  serverTimestamp,
  setDoc,
  where,
  increment,
} from "firebase/firestore";
import { useEffect, useState } from "react";
import { getFirebase } from "./firebase";

const PENDING_KEY = "arc_pending_referral";
export const REFERRAL_XP = 10;

/** Deterministic, shareable referral code derived from uid. */
export function codeForUid(uid: string): string {
  // base32-ish, 8 chars uppercase
  let h = 0;
  for (let i = 0; i < uid.length; i++) h = (h * 31 + uid.charCodeAt(i)) | 0;
  const tail = Math.abs(h).toString(36).toUpperCase().padStart(4, "0").slice(-4);
  const head = uid.replace(/[^a-zA-Z0-9]/g, "").slice(0, 4).toUpperCase().padStart(4, "X");
  return `${head}${tail}`;
}

export function referralLinkFor(code: string): string {
  if (typeof window === "undefined") return `?ref=${code}`;
  const url = new URL(window.location.origin);
  url.searchParams.set("ref", code);
  return url.toString();
}

/** Capture ?ref=CODE from URL on first paint so it survives the OAuth round-trip. */
export function capturePendingReferral() {
  if (typeof window === "undefined") return;
  try {
    const url = new URL(window.location.href);
    const ref = url.searchParams.get("ref");
    if (ref && ref.length >= 4 && ref.length <= 32) {
      window.localStorage.setItem(PENDING_KEY, ref.toUpperCase());
    }
  } catch {
    /* noop */
  }
}

export function consumePendingReferral(): string | null {
  if (typeof window === "undefined") return null;
  try {
    const v = window.localStorage.getItem(PENDING_KEY);
    if (v) window.localStorage.removeItem(PENDING_KEY);
    return v;
  } catch {
    return null;
  }
}

/** Ensures the user doc has its referralCode field set (idempotent). */
export async function ensureReferralCode(uid: string): Promise<string> {
  const code = codeForUid(uid);
  const { db } = getFirebase();
  if (!db) return code;
  const userRef = doc(db, "users", uid);
  const snap = await getDoc(userRef);
  const existing = snap.data()?.referralCode as string | undefined;
  if (existing) return existing;
  await setDoc(
    userRef,
    {
      referralCode: code,
      referralCount: snap.data()?.referralCount ?? 0,
    },
    { merge: true },
  );
  return code;
}

/**
 * Apply a referral code for a newly signed-up user.
 * Rules enforced:
 *  - code must resolve to a different uid
 *  - target user can only be referred once (referredBy set => abort)
 *  - referrer earns +REFERRAL_XP exactly once per invited user
 *  - invited user earns +REFERRAL_XP exactly once (signup bonus)
 */
export async function applyReferralCode(
  invitedUid: string,
  rawCode: string,
): Promise<{ ok: boolean; reason?: string }> {
  const { db } = getFirebase();
  if (!db) return { ok: false, reason: "offline" };
  const code = rawCode.trim().toUpperCase();
  if (!code) return { ok: false, reason: "empty" };

  // Find referrer by code
  const qs = await getDocs(
    query(collection(db, "users"), where("referralCode", "==", code), limit(1)),
  );
  if (qs.empty) return { ok: false, reason: "invalid_code" };
  const referrerSnap = qs.docs[0];
  const referrerUid = referrerSnap.id;
  if (referrerUid === invitedUid) return { ok: false, reason: "self" };

  const invitedRef = doc(db, "users", invitedUid);
  const referrerRef = doc(db, "users", referrerUid);
  const referralRef = doc(db, "referrals", invitedUid); // 1 doc per invited user
  const referrerXpRef = doc(db, "users", referrerUid, "xpEvents", `referral__${invitedUid}`);
  const invitedXpRef = doc(db, "users", invitedUid, "xpEvents", `signup_referral__self`);

  try {
    await runTransaction(db, async (tx) => {
      const [invitedSnap, refSnap, alreadyReferral] = await Promise.all([
        tx.get(invitedRef),
        tx.get(referralRef),
        tx.get(referrerXpRef),
      ]);
      if (!invitedSnap.exists()) throw new Error("invited_missing");
      if (invitedSnap.data()?.referredBy) throw new Error("already_referred");
      if (refSnap.exists()) throw new Error("duplicate");

      // Write referral record
      tx.set(referralRef, {
        invitedUid,
        referrerUid,
        code,
        createdAt: serverTimestamp(),
      });

      // Mark invited user
      tx.update(invitedRef, {
        referredBy: referrerUid,
        referredByCode: code,
        referredAt: serverTimestamp(),
        points: increment(REFERRAL_XP),
      });
      tx.set(invitedXpRef, {
        action: "signup_referral",
        points: REFERRAL_XP,
        createdAt: serverTimestamp(),
        meta: { referrerUid },
      });

      // Reward referrer (idempotent via xpEvents key)
      if (!alreadyReferral.exists()) {
        tx.update(referrerRef, {
          points: increment(REFERRAL_XP),
          referralCount: increment(1),
        });
        tx.set(referrerXpRef, {
          action: "referral",
          points: REFERRAL_XP,
          createdAt: serverTimestamp(),
          meta: { invitedUid },
        });
      }
    });
    return { ok: true };
  } catch (err) {
    const msg = err instanceof Error ? err.message : "error";
    return { ok: false, reason: msg };
  }
}

export type ReferralStats = {
  code: string;
  count: number;
  invited: Array<{ uid: string; createdAt?: { toDate?: () => Date } }>;
};

/** Real-time stats for the current user's referrals. */
export function useReferralStats(uid: string | undefined): ReferralStats & { loading: boolean } {
  const [code, setCode] = useState<string>(uid ? codeForUid(uid) : "");
  const [count, setCount] = useState(0);
  const [invited, setInvited] = useState<ReferralStats["invited"]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!uid) {
      setLoading(false);
      return;
    }
    const { db } = getFirebase();
    if (!db) {
      setLoading(false);
      return;
    }
    setCode(codeForUid(uid));
    void ensureReferralCode(uid).then((c) => setCode(c));

    const unsubUser = onSnapshot(doc(db, "users", uid), (snap) => {
      const data = snap.data();
      if (data?.referralCode) setCode(data.referralCode as string);
      setCount((data?.referralCount as number | undefined) ?? 0);
    });
    const unsubList = onSnapshot(
      query(collection(db, "referrals"), where("referrerUid", "==", uid)),
      (qs) => {
        setInvited(
          qs.docs.map((d) => ({
            uid: (d.data().invitedUid as string) ?? d.id,
            createdAt: d.data().createdAt,
          })),
        );
        setLoading(false);
      },
    );
    return () => {
      unsubUser();
      unsubList();
    };
  }, [uid]);

  return { code, count, invited, loading };
}
