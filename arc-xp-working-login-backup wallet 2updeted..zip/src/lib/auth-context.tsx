import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import {
  onAuthStateChanged,
  signInWithPopup,
  signOut,
  setPersistence,
  browserLocalPersistence,
  type User,
} from "firebase/auth";
import { doc, getDoc, onSnapshot, serverTimestamp, setDoc, updateDoc } from "firebase/firestore";
import { getFirebase, googleProvider } from "./firebase";
import { awardDailyLogin } from "./xp";

export type UserProfile = {
  uid: string;
  name: string;
  username: string;
  email: string;
  photoURL?: string;
  points: number;
  streak: number;
  badges: string[];
  rank?: number;
  joinedAt?: unknown;
  lastLogin?: unknown;
  lastLoginDate?: string;
  walletAddress?: string | null;
  walletProvider?: string | null;
  walletConnectedAt?: unknown;
  lastGMClaim?: unknown;
  gmStreak?: number;
};

type AuthCtx = {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  signInGoogle: () => Promise<void>;
  logout: () => Promise<void>;
};

const Ctx = createContext<AuthCtx>({
  user: null,
  profile: null,
  loading: true,
  signInGoogle: async () => {},
  logout: async () => {},
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  // Start `loading` false so SSR renders the LoginScreen (not a blank spinner).
  // On the client, the effect below flips it to true until onAuthStateChanged resolves.
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true);
    const { auth, db } = getFirebase();
    if (!auth || !db) {
      setLoading(false);
      return;
    }
    void setPersistence(auth, browserLocalPersistence);

    let unsubProfile: (() => void) | null = null;

    const unsub = onAuthStateChanged(auth, async (u) => {
      unsubProfile?.();
      unsubProfile = null;
      setUser(u);

      if (!u) {
        setProfile(null);
        setLoading(false);
        return;
      }

      const ref = doc(db, "users", u.uid);
      const name = u.displayName ?? u.email?.split("@")[0] ?? "Explorer";

      const existing = await getDoc(ref);
      if (!existing.exists()) {
        await setDoc(ref, {
          uid: u.uid,
          name,
          username: name,
          email: u.email ?? "",
          photoURL: u.photoURL ?? "",
          points: 0,
          streak: 0,
          badges: [],
          rank: 0,
          joinedAt: serverTimestamp(),
          lastLogin: serverTimestamp(),
        });
      } else {
        await updateDoc(ref, {
          name,
          email: u.email ?? "",
          photoURL: u.photoURL ?? "",
        });
      }

      // Daily login XP (idempotent per UTC day).
      try {
        await awardDailyLogin(u.uid);
      } catch (err) {
        console.warn("daily login award failed", err);
      }

      // Live subscribe to profile so points/streak update in real time.
      unsubProfile = onSnapshot(ref, (snap) => {
        if (snap.exists()) setProfile(snap.data() as UserProfile);
        setLoading(false);
      });
    });

    return () => {
      unsubProfile?.();
      unsub();
    };
  }, []);

  const signInGoogle = async () => {
    const { auth } = getFirebase();
    if (!auth) return;
    await setPersistence(auth, browserLocalPersistence);
    await signInWithPopup(auth, googleProvider);
  };

  const logout = async () => {
    const { auth } = getFirebase();
    if (!auth) return;
    await signOut(auth);
  };

  return (
    <Ctx.Provider value={{ user, profile, loading, signInGoogle, logout }}>
      {children}
    </Ctx.Provider>
  );
}

export const useAuth = () => useContext(Ctx);
