import { createFileRoute } from "@tanstack/react-router";
import { Calendar, Users, Mic, Video, MessageCircle, Sparkles, Loader2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { upcomingEvents } from "@/lib/demo-data";
import { useAuth } from "@/lib/auth-context";
import { awardXp, XP_ACTIONS } from "@/lib/xp";
import { useXpEvents } from "@/lib/use-xp-events";

export const Route = createFileRoute("/_app/events")({
  head: () => ({ meta: [{ title: "Events — ARC XP" }] }),
  component: Events,
});

const typeIcons: Record<string, typeof Mic> = {
  "Twitter Space": Mic,
  Webinar: Video,
  AMA: MessageCircle,
  Event: Sparkles,
};

const dedupe = (id: number) => `event:${id}`;
const eventDocId = (id: number) => `event_participation__${dedupe(id)}`;

function Events() {
  const { user } = useAuth();
  const { ids } = useXpEvents(user?.uid);
  const [pending, setPending] = useState<number | null>(null);

  const join = async (id: number) => {
    if (!user || ids.has(eventDocId(id))) return;
    setPending(id);
    try {
      const res = await awardXp(user.uid, "event_participation", dedupe(id));
      if (res) {
        toast.success("Event joined!", {
          description: `+${res.awarded} XP · Total: ${res.total}`,
        });
      }
    } catch (e) {
      console.warn("award xp failed", e);
    } finally {
      setPending(null);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-3xl sm:text-4xl font-bold">
          <span className="gradient-text">Events</span>
        </h1>
        <p className="text-muted-foreground mt-1">
          Twitter Spaces, webinars, and community gatherings. Earn{" "}
          <span className="text-brand-cyan font-medium">+{XP_ACTIONS.event_participation} XP</span> per event you join.
        </p>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {upcomingEvents.map((e, i) => {
          const Icon = typeIcons[e.type] ?? Calendar;
          const joined = ids.has(eventDocId(e.id));
          const isPending = pending === e.id;
          return (
            <div
              key={e.id}
              className="glass rounded-2xl p-5 flex flex-col gap-4 hover:scale-[1.02] transition animate-scale-in"
              style={{ animationDelay: `${i * 50}ms` }}
            >
              <div className="flex items-center justify-between">
                <div className="h-10 w-10 rounded-xl gradient-bg flex items-center justify-center glow">
                  <Icon className="h-5 w-5 text-white" />
                </div>
                <span className="text-xs px-3 py-1 rounded-full glass-strong">{e.type}</span>
              </div>
              <div>
                <h3 className="font-semibold text-lg leading-tight">{e.title}</h3>
                <p className="text-sm text-muted-foreground mt-1">Hosted by {e.host}</p>
              </div>
              <div className="text-sm text-brand-cyan flex items-center gap-2">
                <Calendar className="h-4 w-4" /> {e.date}
              </div>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Users className="h-3.5 w-3.5" /> {e.going.toLocaleString()} going
              </div>
              <button
                onClick={() => join(e.id)}
                disabled={joined || isPending || !user}
                className={`mt-auto py-2.5 rounded-xl text-sm font-semibold transition flex items-center justify-center gap-2 ${
                  joined
                    ? "glass-strong text-brand-cyan ring-1 ring-brand-cyan/50 cursor-default"
                    : "gradient-bg text-primary-foreground glow hover:opacity-90 disabled:opacity-50"
                }`}
              >
                {isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : joined ? (
                  "✓ Joined"
                ) : (
                  `RSVP · +${XP_ACTIONS.event_participation} XP`
                )}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}
