import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import {
  onAuthStateChanged,
  signInWithPopup,
  signOut,
  setPersistence,
  browserLocalPersistence,
  type User,
} from "firebase/auth";
import { doc, getDoc, setDoc, serverTimestamp } from "firebase/firestore";
import { getFirebase, googleProvider } from "./firebase";

export type UserProfile = {
  uid: string;
  username: string;
  email: string;
  photoURL?: string;
  points: number;
  streak: number;
  badges: string[];
  createdAt?: unknown;
};

type AuthCtx = {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  signInGoogle: () => Promise<void>;
  logout: () => Promise<void>;
};

const Ctx = createContext<AuthCtx>({
  user: null,
  profile: null,
  loading: true,
  signInGoogle: async () => {},
  logout: async () => {},
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const { auth, db } = getFirebase();
    if (!auth || !db) {
      setLoading(false);
      return;
    }
    void setPersistence(auth, browserLocalPersistence);
    const unsub = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      if (u) {
        const ref = doc(db, "users", u.uid);
        const snap = await getDoc(ref);
        if (!snap.exists()) {
          const fresh: UserProfile = {
            uid: u.uid,
            username: u.displayName ?? (u.email?.split("@")[0] ?? "Explorer"),
            email: u.email ?? "",
            photoURL: u.photoURL ?? "",
            points: 0,
            streak: 1,
            badges: [],
          };
          await setDoc(ref, { ...fresh, createdAt: serverTimestamp() });
          setProfile(fresh);
        } else {
          setProfile(snap.data() as UserProfile);
        }
      } else {
        setProfile(null);
      }
      setLoading(false);
    });
    return () => unsub();
  }, []);

  const signInGoogle = async () => {
    const { auth } = getFirebase();
    if (!auth) return;
    await setPersistence(auth, browserLocalPersistence);
    await signInWithPopup(auth, googleProvider);
  };

  const logout = async () => {
    const { auth } = getFirebase();
    if (!auth) return;
    await signOut(auth);
  };

  return (
    <Ctx.Provider value={{ user, profile, loading, signInGoogle, logout }}>
      {children}
    </Ctx.Provider>
  );
}

export const useAuth = () => useContext(Ctx);