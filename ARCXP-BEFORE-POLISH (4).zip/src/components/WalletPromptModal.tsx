import { lazy, Suspense, useEffect, useState } from "react";
import { toast } from "sonner";
import { useAuth } from "@/lib/auth-context";
import { connectAnyWallet } from "@/lib/wallet";
import type { WalletOption } from "@/lib/wallet-providers";

const WalletSelectModal = lazy(() =>
  import("./WalletSelectModal").then((m) => ({ default: m.WalletSelectModal })),
);

const DISMISS_KEY = "arcxp:wallet-prompt-dismissed";

/**
 * Auto-prompts authenticated users (typically Google sign-in) to link a
 * wallet if they don't have one connected yet. Dismissible for the session.
 */
export function WalletPromptModal() {
  const { user, profile, loading } = useAuth();
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (loading || !user || !profile) return;
    if (profile.walletAddress) return;
    try {
      if (sessionStorage.getItem(DISMISS_KEY) === "1") return;
    } catch {
      /* sessionStorage may be unavailable in private mode */
    }
    const t = setTimeout(() => setOpen(true), 800);
    return () => clearTimeout(t);
  }, [user, profile, loading]);

  const handleClose = () => {
    setOpen(false);
    try { sessionStorage.setItem(DISMISS_KEY, "1"); } catch { /* noop */ }
  };

  if (!user || !profile || profile.walletAddress) return null;

  return (
    <Suspense fallback={null}>
      <WalletSelectModal
        open={open}
        onClose={handleClose}
        onSelect={async (w: WalletOption) => {
          await connectAnyWallet(user.uid, w);
          toast.success("Wallet connected", {
            description: `${w.name} linked to your ARC XP account.`,
          });
        }}
        title="Link your wallet"
        subtitle="Connect a wallet to claim XP rewards, mint NFT badges, and earn on-chain."
      />
    </Suspense>
  );
}