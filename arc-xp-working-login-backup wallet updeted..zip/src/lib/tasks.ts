import { XP_ACTIONS, type XpAction } from "./xp";

export type TaskRepeat = "daily" | "once";

export type TaskDef = {
  id: string;
  title: string;
  action: XpAction;
  repeat: TaskRepeat;
};

export const TASKS: TaskDef[] = [
  { id: "watch_video",         title: "Watch a video",            action: "watch_video",         repeat: "daily" },
  { id: "read_content",        title: "Read featured content",    action: "read_content",        repeat: "daily" },
  { id: "publish_post",        title: "Publish a forum post",     action: "publish_post",        repeat: "daily" },
  { id: "event_participation", title: "Join a community event",   action: "event_participation", repeat: "daily" },
  { id: "accepted_answer",     title: "Get an accepted answer",   action: "accepted_answer",     repeat: "once"  },
  { id: "author_article",      title: "Author an article",        action: "author_article",      repeat: "once"  },
  { id: "video_speaker",       title: "Speak in a video session", action: "video_speaker",       repeat: "once"  },
];

export const taskPoints = (t: TaskDef) => XP_ACTIONS[t.action];

const todayKey = () => new Date().toISOString().slice(0, 10);

/** dedupeKey strategy: daily tasks reset per UTC day; once tasks are lifetime. */
export function taskDedupeKey(t: TaskDef): string {
  return t.repeat === "daily" ? todayKey() : "lifetime";
}

export function taskEventId(t: TaskDef): string {
  return `${t.action}__${taskDedupeKey(t)}`;
}