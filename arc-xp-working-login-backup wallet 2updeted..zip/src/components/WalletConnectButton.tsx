import { useState } from "react";
import { Wallet, Loader2, ChevronDown, LogOut } from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { connectMetaMask, disconnectWallet, shortAddress } from "@/lib/wallet";

export function WalletConnectButton({ compact = false }: { compact?: boolean }) {
  const { user, profile } = useAuth();
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const address = profile?.walletAddress as string | undefined;

  const run = async (fn: () => Promise<unknown>) => {
    if (!user) return;
    setBusy(true);
    setErr(null);
    try {
      await fn();
      setOpen(false);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Connection failed");
    } finally {
      setBusy(false);
    }
  };

  if (!user) return null;

  if (address) {
    return (
      <div className="relative">
        <button
          onClick={() => setOpen((o) => !o)}
          className={`glass-strong rounded-xl px-3 sm:px-4 py-2 flex items-center gap-2 text-xs sm:text-sm hover:bg-white/[0.06] transition ${compact ? "" : ""}`}
        >
          <span className="h-2 w-2 rounded-full bg-emerald-400 glow-sm" />
          <Wallet className="h-4 w-4 text-brand-cyan" />
          <span className="font-mono">{shortAddress(address)}</span>
          <ChevronDown className="h-3.5 w-3.5 opacity-60" />
        </button>
        {open && (
          <div className="absolute right-0 mt-2 w-56 glass-strong rounded-xl p-2 z-50 border border-white/10">
            <div className="px-3 py-2 text-xs text-muted-foreground">
              Connected wallet
              <div className="text-foreground font-mono mt-1 break-all">{address}</div>
            </div>
            <button
              onClick={() => run(() => disconnectWallet(user.uid))}
              disabled={busy}
              className="w-full text-left px-3 py-2 rounded-lg hover:bg-white/[0.06] text-sm flex items-center gap-2 text-red-400"
            >
              <LogOut className="h-4 w-4" /> Disconnect
            </button>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="relative">
      <button
        onClick={() => run(() => connectMetaMask(user.uid))}
        disabled={busy}
        className="gradient-bg text-primary-foreground font-semibold px-4 py-2 rounded-xl glow hover:opacity-90 transition flex items-center gap-2 text-sm disabled:opacity-60"
      >
        {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Wallet className="h-4 w-4" />}
        {compact ? "Connect" : "Connect Wallet"}
      </button>
      {err && (
        <div className="absolute right-0 mt-2 w-64 glass-strong rounded-xl p-3 z-50 border border-white/10 text-xs text-red-400 break-words">
          {err}
        </div>
      )}
    </div>
  );
}
