import { doc, runTransaction, serverTimestamp, increment } from "firebase/firestore";
import { getFirebase } from "./firebase";

export const XP_ACTIONS = {
  daily_login: 5,
  watch_video: 4,
  read_content: 2,
  publish_post: 10,
  accepted_answer: 30,
  event_participation: 20,
  author_article: 200,
  video_speaker: 500,
} as const;

export type XpAction = keyof typeof XP_ACTIONS;

const todayKey = () => new Date().toISOString().slice(0, 10);

/**
 * Awards XP atomically. `dedupeKey` makes the action idempotent — if the same
 * (action, dedupeKey) was already awarded for this user, the call is a no-op.
 */
export async function awardXp(
  uid: string,
  action: XpAction,
  dedupeKey: string,
): Promise<{ awarded: number; total: number } | null> {
  const { db } = getFirebase();
  if (!db) return null;
  const userRef = doc(db, "users", uid);
  const eventRef = doc(db, "users", uid, "xpEvents", `${action}__${dedupeKey}`);
  const points = XP_ACTIONS[action];

  return runTransaction(db, async (tx) => {
    const eventSnap = await tx.get(eventRef);
    if (eventSnap.exists()) return null;
    const userSnap = await tx.get(userRef);
    const current = (userSnap.data()?.points as number | undefined) ?? 0;
    tx.set(eventRef, { action, points, createdAt: serverTimestamp() });
    tx.update(userRef, { points: increment(points) });
    return { awarded: points, total: current + points };
  });
}

/** Daily login: +5 XP and streak bump, only once per calendar day (UTC). */
export async function awardDailyLogin(uid: string) {
  const { db } = getFirebase();
  if (!db) return;
  const userRef = doc(db, "users", uid);
  const today = todayKey();

  await runTransaction(db, async (tx) => {
    const snap = await tx.get(userRef);
    if (!snap.exists()) return;
    const data = snap.data();
    const last = data.lastLoginDate as string | undefined;
    if (last === today) return;

    const yesterday = new Date(Date.now() - 86_400_000).toISOString().slice(0, 10);
    const nextStreak = last === yesterday ? (data.streak ?? 0) + 1 : 1;

    tx.update(userRef, {
      points: increment(XP_ACTIONS.daily_login),
      streak: nextStreak,
      lastLoginDate: today,
      lastLogin: serverTimestamp(),
    });
    const eventRef = doc(db, "users", uid, "xpEvents", `daily_login__${today}`);
    tx.set(eventRef, {
      action: "daily_login",
      points: XP_ACTIONS.daily_login,
      createdAt: serverTimestamp(),
    });
  });
}
