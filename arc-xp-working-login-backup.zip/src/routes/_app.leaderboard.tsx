import { createFileRoute } from "@tanstack/react-router";
import { Crown, Medal, Trophy } from "lucide-react";
import { leaderboard, currentUser } from "@/lib/demo-data";

export const Route = createFileRoute("/_app/leaderboard")({
  head: () => ({ meta: [{ title: "Leaderboard — ARC XP" }] }),
  component: Leaderboard,
});

function Leaderboard() {
  const top3 = leaderboard.slice(0, 3);
  const rest = leaderboard.slice(3);
  const podiumOrder = [top3[1], top3[0], top3[2]]; // 2, 1, 3
  const podiumStyles = ["h-32", "h-44", "h-24"];
  const podiumIcons = [Medal, Crown, Trophy];
  const podiumColors = ["from-slate-300 to-slate-500", "from-yellow-300 to-orange-500", "from-orange-400 to-amber-700"];

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-3xl sm:text-4xl font-bold">
          <span className="gradient-text">Leaderboard</span>
        </h1>
        <p className="text-muted-foreground mt-1">Top contributors making ARC happen.</p>
      </div>

      {/* Podium */}
      <div className="glass rounded-2xl p-4 sm:p-8">
        <div className="flex items-end justify-center gap-2 sm:gap-6">
          {podiumOrder.map((u, i) => {
            const Icon = podiumIcons[i];
            return (
              <div key={u.rank} className="flex flex-col items-center gap-2 sm:gap-3 flex-1 min-w-0 max-w-[180px]">
                <img src={u.avatar} alt={u.name} className="h-12 w-12 sm:h-20 sm:w-20 rounded-full ring-2 ring-white/20 animate-float" style={{ animationDelay: `${i * 200}ms` }} />
                <div className="text-center w-full">
                  <div className="font-semibold text-xs sm:text-base truncate">{u.name}</div>
                  <div className="text-[11px] sm:text-xs gradient-text font-bold">{u.points.toLocaleString()}</div>
                </div>
                <div className={`w-full ${podiumStyles[i]} rounded-t-2xl bg-gradient-to-t ${podiumColors[i]} flex items-start justify-center pt-2 sm:pt-3 glow-sm`}>
                  <Icon className="h-5 w-5 sm:h-6 sm:w-6 text-white" />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Rest of list */}
      <div className="glass rounded-2xl p-3 sm:p-6">
        <div className="space-y-2">
          {rest.map((u) => {
            const isMe = u.name === currentUser.username;
            return (
              <div
                key={u.rank}
                className={`flex items-center gap-3 sm:gap-4 p-3 sm:p-4 rounded-xl transition ${
                  isMe ? "glass-strong glow ring-1 ring-brand-purple/50" : "hover:bg-white/5"
                }`}
              >
                <div className="w-6 sm:w-8 text-center font-bold text-muted-foreground text-sm">{u.rank}</div>
                <img src={u.avatar} alt={u.name} className="h-9 w-9 sm:h-10 sm:w-10 rounded-full ring-1 ring-white/10 shrink-0" />
                <div className="flex-1 min-w-0">
                  <div className="font-medium truncate text-sm sm:text-base">
                    {u.name} {isMe && <span className="text-xs text-brand-cyan">(you)</span>}
                  </div>
                  <div className="text-xs text-muted-foreground">Contributor</div>
                </div>
                <div className="text-right shrink-0">
                  <div className="font-bold gradient-text text-sm sm:text-base">{u.points.toLocaleString()}</div>
                  <div className="text-[10px] sm:text-xs text-muted-foreground">points</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}