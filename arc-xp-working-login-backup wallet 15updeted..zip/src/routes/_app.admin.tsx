import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import {
  collection,
  deleteDoc,
  doc,
  limit,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  increment,
  addDoc,
  getDocs,
  Timestamp,
} from "firebase/firestore";
import {
  Shield,
  Users,
  Calendar,
  Activity as ActivityIcon,
  Search,
  Plus,
  Minus,
  Trash2,
  Edit3,
  Loader2,
  Trophy,
  Award,
  Sparkles,
  Wallet,
  X,
  Check,
} from "lucide-react";
import { toast } from "sonner";
import { useAuth, type UserProfile } from "@/lib/auth-context";
import { useIsAdmin } from "@/lib/admin";
import { getFirebase } from "@/lib/firebase";
import { BADGE_CATALOG } from "@/lib/badges";
import { actionLabel, type ActivityRow } from "@/lib/use-activity";

export const Route = createFileRoute("/_app/admin")({
  head: () => ({ meta: [{ title: "Admin — ARC XP" }] }),
  component: AdminPage,
});

type Tab = "users" | "events" | "activity" | "stats";

function AdminPage() {
  const navigate = useNavigate();
  const { isAdmin, loading } = useIsAdmin();
  const [tab, setTab] = useState<Tab>("users");

  useEffect(() => {
    if (!loading && !isAdmin) {
      toast.error("Admins only", { description: "You don't have access to this page." });
      void navigate({ to: "/" });
    }
  }, [isAdmin, loading, navigate]);

  if (loading) {
    return (
      <div className="min-h-[40vh] flex items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-brand-cyan" />
      </div>
    );
  }
  if (!isAdmin) return null;

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-3">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full glass-strong text-xs text-brand-cyan mb-3">
            <Shield className="h-3.5 w-3.5" /> Admin Console
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold">
            <span className="gradient-text">Mission Control</span>
          </h1>
          <p className="text-muted-foreground mt-1 text-sm">
            Manage users, XP, badges, events, and monitor activity across the protocol.
          </p>
        </div>
      </div>

      <div className="glass rounded-2xl p-1.5 flex flex-wrap gap-1 w-full sm:w-fit">
        {(
          [
            { id: "users", label: "Users", icon: Users },
            { id: "events", label: "Events", icon: Calendar },
            { id: "activity", label: "Activity", icon: ActivityIcon },
            { id: "stats", label: "Stats", icon: Trophy },
          ] as const
        ).map((t) => {
          const Icon = t.icon;
          const active = tab === t.id;
          return (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition ${
                active
                  ? "gradient-bg text-primary-foreground glow"
                  : "text-muted-foreground hover:text-foreground hover:bg-white/5"
              }`}
            >
              <Icon className="h-4 w-4" />
              {t.label}
            </button>
          );
        })}
      </div>

      {tab === "users" && <UsersPanel />}
      {tab === "events" && <EventsPanel />}
      {tab === "activity" && <ActivityPanel />}
      {tab === "stats" && <StatsPanel />}
    </div>
  );
}

// -------------------- USERS --------------------

function UsersPanel() {
  const [rows, setRows] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [editing, setEditing] = useState<UserProfile | null>(null);

  useEffect(() => {
    const { db } = getFirebase();
    if (!db) return;
    const q = query(collection(db, "users"), orderBy("points", "desc"), limit(200));
    const unsub = onSnapshot(q, (snap) => {
      setRows(snap.docs.map((d) => d.data() as UserProfile));
      setLoading(false);
    });
    return () => unsub();
  }, []);

  const filtered = useMemo(() => {
    const s = search.trim().toLowerCase();
    if (!s) return rows;
    return rows.filter(
      (r) =>
        (r.name ?? "").toLowerCase().includes(s) ||
        (r.username ?? "").toLowerCase().includes(s) ||
        (r.email ?? "").toLowerCase().includes(s) ||
        (r.walletAddress ?? "").toLowerCase().includes(s),
    );
  }, [rows, search]);

  return (
    <div className="space-y-4">
      <div className="glass rounded-2xl p-3 flex items-center gap-2">
        <Search className="h-4 w-4 text-muted-foreground ml-1" />
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search by name, email, or wallet…"
          className="bg-transparent outline-none flex-1 text-sm placeholder:text-muted-foreground"
        />
        <span className="text-xs text-muted-foreground px-2">{filtered.length} users</span>
      </div>

      <div className="glass rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="text-xs uppercase tracking-wider text-muted-foreground bg-white/5">
              <tr>
                <th className="text-left px-4 py-3">User</th>
                <th className="text-left px-4 py-3 hidden md:table-cell">Email</th>
                <th className="text-right px-4 py-3">XP</th>
                <th className="text-right px-4 py-3 hidden sm:table-cell">Streak</th>
                <th className="text-left px-4 py-3 hidden lg:table-cell">Wallet</th>
                <th className="text-right px-4 py-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading && (
                <tr>
                  <td colSpan={6} className="px-4 py-10 text-center text-muted-foreground">
                    <Loader2 className="h-5 w-5 animate-spin inline" />
                  </td>
                </tr>
              )}
              {!loading && filtered.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-4 py-10 text-center text-muted-foreground">
                    No users found.
                  </td>
                </tr>
              )}
              {filtered.map((u) => (
                <tr key={u.uid} className="border-t border-white/5 hover:bg-white/[0.03]">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3 min-w-0">
                      {u.photoURL ? (
                        <img src={u.photoURL} alt="" className="h-8 w-8 rounded-full ring-1 ring-white/10 shrink-0" />
                      ) : (
                        <div className="h-8 w-8 rounded-full gradient-bg flex items-center justify-center text-xs font-bold shrink-0">
                          {(u.username ?? "U")[0]?.toUpperCase()}
                        </div>
                      )}
                      <div className="min-w-0">
                        <div className="font-medium truncate">{u.username ?? u.name ?? "—"}</div>
                        <div className="text-[11px] text-muted-foreground truncate md:hidden">{u.email}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 hidden md:table-cell text-muted-foreground truncate max-w-[220px]">
                    {u.email}
                  </td>
                  <td className="px-4 py-3 text-right font-semibold text-brand-cyan">
                    {(u.points ?? 0).toLocaleString()}
                  </td>
                  <td className="px-4 py-3 text-right hidden sm:table-cell">{u.streak ?? 0}</td>
                  <td className="px-4 py-3 hidden lg:table-cell">
                    {u.walletAddress ? (
                      <span className="font-mono text-[11px] glass-strong px-2 py-1 rounded-md inline-flex items-center gap-1">
                        <Wallet className="h-3 w-3" />
                        {u.walletAddress.slice(0, 6)}…{u.walletAddress.slice(-4)}
                      </span>
                    ) : (
                      <span className="text-muted-foreground text-xs">—</span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="inline-flex items-center gap-1">
                      <XPButton uid={u.uid} delta={10} />
                      <XPButton uid={u.uid} delta={-10} />
                      <button
                        onClick={() => setEditing(u)}
                        className="p-2 rounded-lg hover:bg-white/10 transition"
                        title="Manage"
                      >
                        <Edit3 className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {editing && <UserEditor user={editing} onClose={() => setEditing(null)} />}
    </div>
  );
}

function XPButton({ uid, delta }: { uid: string; delta: number }) {
  const [busy, setBusy] = useState(false);
  const Icon = delta > 0 ? Plus : Minus;
  const onClick = async () => {
    const { db } = getFirebase();
    if (!db) return;
    setBusy(true);
    try {
      await updateDoc(doc(db, "users", uid), { points: increment(delta) });
      toast.success(`${delta > 0 ? "+" : ""}${delta} XP applied`);
    } catch (e) {
      toast.error("Failed", { description: e instanceof Error ? e.message : String(e) });
    } finally {
      setBusy(false);
    }
  };
  return (
    <button
      onClick={onClick}
      disabled={busy}
      className={`p-2 rounded-lg transition ${
        delta > 0 ? "hover:bg-emerald-500/10 text-emerald-400" : "hover:bg-rose-500/10 text-rose-400"
      } disabled:opacity-50`}
      title={`${delta > 0 ? "Add" : "Remove"} ${Math.abs(delta)} XP`}
    >
      {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Icon className="h-4 w-4" />}
    </button>
  );
}

function UserEditor({ user, onClose }: { user: UserProfile; onClose: () => void }) {
  const [xp, setXp] = useState<string>(String(user.points ?? 0));
  const [busy, setBusy] = useState(false);
  const [badges, setBadges] = useState<string[]>(user.badges ?? []);

  const save = async () => {
    const { db } = getFirebase();
    if (!db) return;
    setBusy(true);
    try {
      const n = Number(xp);
      await updateDoc(doc(db, "users", user.uid), {
        points: Number.isFinite(n) ? Math.max(0, Math.floor(n)) : 0,
        badges,
      });
      toast.success("User updated");
      onClose();
    } catch (e) {
      toast.error("Failed", { description: e instanceof Error ? e.message : String(e) });
    } finally {
      setBusy(false);
    }
  };

  const toggle = (id: string) =>
    setBadges((b) => (b.includes(id) ? b.filter((x) => x !== id) : [...b, id]));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className="glass rounded-2xl p-6 w-full max-w-lg max-h-[85vh] overflow-y-auto relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-lg hover:bg-white/10"
        >
          <X className="h-4 w-4" />
        </button>
        <div className="flex items-center gap-3 mb-5">
          {user.photoURL ? (
            <img src={user.photoURL} className="h-10 w-10 rounded-full ring-1 ring-white/20" alt="" />
          ) : (
            <div className="h-10 w-10 rounded-full gradient-bg" />
          )}
          <div>
            <div className="font-semibold">{user.username}</div>
            <div className="text-xs text-muted-foreground">{user.email}</div>
          </div>
        </div>

        <label className="text-xs uppercase tracking-wider text-muted-foreground">XP Total</label>
        <input
          type="number"
          value={xp}
          onChange={(e) => setXp(e.target.value)}
          className="mt-1 w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-sm outline-none focus:border-brand-cyan/50"
        />

        {user.walletAddress && (
          <div className="mt-4">
            <div className="text-xs uppercase tracking-wider text-muted-foreground mb-1">Wallet</div>
            <div className="glass-strong rounded-xl px-3 py-2 font-mono text-xs break-all">
              {user.walletAddress}
            </div>
          </div>
        )}

        <div className="mt-5">
          <div className="text-xs uppercase tracking-wider text-muted-foreground mb-2 flex items-center gap-2">
            <Award className="h-3.5 w-3.5" /> Badges
          </div>
          <div className="grid grid-cols-2 gap-2 max-h-64 overflow-y-auto pr-1">
            {BADGE_CATALOG.map((b) => {
              const on = badges.includes(b.id);
              return (
                <button
                  key={b.id}
                  onClick={() => toggle(b.id)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-xl text-left text-sm transition ${
                    on
                      ? "glass-strong ring-1 ring-brand-cyan/60 text-foreground"
                      : "bg-white/5 hover:bg-white/10 text-muted-foreground"
                  }`}
                >
                  <span className="text-lg">{b.icon}</span>
                  <span className="flex-1 truncate">{b.name}</span>
                  {on && <Check className="h-3.5 w-3.5 text-brand-cyan" />}
                </button>
              );
            })}
          </div>
        </div>

        <div className="mt-6 flex justify-end gap-2">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-sm"
          >
            Cancel
          </button>
          <button
            onClick={save}
            disabled={busy}
            className="px-4 py-2 rounded-xl gradient-bg text-primary-foreground text-sm font-semibold glow disabled:opacity-50 flex items-center gap-2"
          >
            {busy && <Loader2 className="h-4 w-4 animate-spin" />} Save
          </button>
        </div>
      </div>
    </div>
  );
}

// -------------------- EVENTS --------------------

type AdminEvent = {
  id: string;
  title: string;
  type: string;
  date: string;
  host: string;
  going?: number;
  attendees?: number;
  description?: string;
  startAt?: Timestamp;
};

function EventsPanel() {
  const [rows, setRows] = useState<AdminEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<AdminEvent | null>(null);
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    const { db } = getFirebase();
    if (!db) return;
    const q = query(collection(db, "events"), orderBy("createdAt", "desc"));
    const unsub = onSnapshot(q, (snap) => {
      setRows(snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<AdminEvent, "id">) })));
      setLoading(false);
    });
    return () => unsub();
  }, []);

  const remove = async (id: string) => {
    if (!confirm("Delete this event?")) return;
    const { db } = getFirebase();
    if (!db) return;
    try {
      await deleteDoc(doc(db, "events", id));
      toast.success("Event deleted");
    } catch (e) {
      toast.error("Delete failed", { description: e instanceof Error ? e.message : String(e) });
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <button
          onClick={() => setCreating(true)}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl gradient-bg text-primary-foreground font-semibold text-sm glow"
        >
          <Plus className="h-4 w-4" /> New Event
        </button>
      </div>

      {loading ? (
        <div className="glass rounded-2xl p-10 text-center">
          <Loader2 className="h-5 w-5 animate-spin inline text-brand-cyan" />
        </div>
      ) : rows.length === 0 ? (
        <div className="glass rounded-2xl p-10 text-center text-muted-foreground text-sm">
          No events yet. Create one to get started.
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {rows.map((e) => (
            <div key={e.id} className="glass rounded-2xl p-5 flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <span className="text-xs px-3 py-1 rounded-full glass-strong">{e.type}</span>
                <div className="flex items-center gap-1">
                  <button onClick={() => setEditing(e)} className="p-2 rounded-lg hover:bg-white/10">
                    <Edit3 className="h-4 w-4" />
                  </button>
                  <button onClick={() => remove(e.id)} className="p-2 rounded-lg hover:bg-rose-500/10 text-rose-400">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
              <div>
                <h3 className="font-semibold leading-tight">{e.title}</h3>
                <p className="text-xs text-muted-foreground mt-1">Hosted by {e.host}</p>
              </div>
              <div className="text-sm text-brand-cyan flex items-center gap-2">
                <Calendar className="h-4 w-4" /> {e.date}
              </div>
            </div>
          ))}
        </div>
      )}

      {(editing || creating) && (
        <EventEditor
          event={editing}
          onClose={() => {
            setEditing(null);
            setCreating(false);
          }}
        />
      )}
    </div>
  );
}

function EventEditor({ event, onClose }: { event: AdminEvent | null; onClose: () => void }) {
  const [title, setTitle] = useState(event?.title ?? "");
  const [type, setType] = useState(event?.type ?? "Twitter Space");
  const [date, setDate] = useState(event?.date ?? "");
  const [host, setHost] = useState(event?.host ?? "");
  const [description, setDescription] = useState(event?.description ?? "");
  const [startAtLocal, setStartAtLocal] = useState(() => {
    const d = event?.startAt?.toDate?.();
    if (!d) return "";
    const pad = (n: number) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  });
  const [busy, setBusy] = useState(false);

  const save = async () => {
    const { db } = getFirebase();
    if (!db) return;
    if (!title.trim() || !host.trim() || (!date.trim() && !startAtLocal)) {
      toast.error("Please fill all fields");
      return;
    }
    setBusy(true);
    try {
      const startAt = startAtLocal ? Timestamp.fromDate(new Date(startAtLocal)) : null;
      const dateLabel =
        date.trim() ||
        (startAt
          ? startAt.toDate().toLocaleString(undefined, {
              month: "short",
              day: "numeric",
              year: "numeric",
              hour: "numeric",
              minute: "2-digit",
            })
          : "");
      if (event) {
        await updateDoc(doc(db, "events", event.id), {
          title,
          type,
          date: dateLabel,
          host,
          description,
          ...(startAt ? { startAt } : {}),
        });
        toast.success("Event updated");
      } else {
        await addDoc(collection(db, "events"), {
          title,
          type,
          date: dateLabel,
          host,
          description,
          ...(startAt ? { startAt } : {}),
          going: 0,
          attendees: 0,
          createdAt: serverTimestamp(),
        });
        toast.success("Event created");
      }
      onClose();
    } catch (e) {
      toast.error("Save failed", { description: e instanceof Error ? e.message : String(e) });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className="glass rounded-2xl p-6 w-full max-w-md max-h-[85vh] overflow-y-auto relative">
        <button onClick={onClose} className="absolute top-4 right-4 p-2 rounded-lg hover:bg-white/10">
          <X className="h-4 w-4" />
        </button>
        <h2 className="text-lg font-bold mb-4 flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-brand-cyan" />
          {event ? "Edit Event" : "New Event"}
        </h2>
        <div className="space-y-3">
          <Field label="Title">
            <input value={title} onChange={(e) => setTitle(e.target.value)} className={inputCls} />
          </Field>
          <Field label="Type">
            <select value={type} onChange={(e) => setType(e.target.value)} className={inputCls}>
              <option>Twitter Space</option>
              <option>Webinar</option>
              <option>AMA</option>
              <option>Event</option>
            </select>
          </Field>
          <Field label="Starts At">
            <input
              type="datetime-local"
              value={startAtLocal}
              onChange={(e) => setStartAtLocal(e.target.value)}
              className={inputCls}
            />
          </Field>
          <Field label="Date Label (optional override)">
            <input
              value={date}
              onChange={(e) => setDate(e.target.value)}
              placeholder="Auto-generated from Starts At if blank"
              className={inputCls}
            />
          </Field>
          <Field label="Host">
            <input value={host} onChange={(e) => setHost(e.target.value)} className={inputCls} />
          </Field>
          <Field label="Description">
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={4}
              className={inputCls}
              placeholder="What is this event about?"
            />
          </Field>
        </div>
        <div className="mt-6 flex justify-end gap-2">
          <button onClick={onClose} className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-sm">
            Cancel
          </button>
          <button
            onClick={save}
            disabled={busy}
            className="px-4 py-2 rounded-xl gradient-bg text-primary-foreground text-sm font-semibold glow disabled:opacity-50 flex items-center gap-2"
          >
            {busy && <Loader2 className="h-4 w-4 animate-spin" />}
            {event ? "Save" : "Create"}
          </button>
        </div>
      </div>
    </div>
  );
}

const inputCls =
  "w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-sm outline-none focus:border-brand-cyan/50";

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="text-xs uppercase tracking-wider text-muted-foreground mb-1">{label}</div>
      {children}
    </div>
  );
}

// -------------------- ACTIVITY --------------------

function ActivityPanel() {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [selected, setSelected] = useState<string>("");
  const [rows, setRows] = useState<ActivityRow[]>([]);
  const { user } = useAuth();

  useEffect(() => {
    const { db } = getFirebase();
    if (!db) return;
    const q = query(collection(db, "users"), orderBy("points", "desc"), limit(50));
    const unsub = onSnapshot(q, (snap) => {
      const list = snap.docs.map((d) => d.data() as UserProfile);
      setUsers(list);
      if (!selected) setSelected(user?.uid ?? list[0]?.uid ?? "");
    });
    return () => unsub();
  }, [user?.uid, selected]);

  useEffect(() => {
    if (!selected) return;
    const { db } = getFirebase();
    if (!db) return;
    const q = query(
      collection(db, "users", selected, "xpEvents"),
      orderBy("createdAt", "desc"),
      limit(100),
    );
    const unsub = onSnapshot(q, (snap) => {
      setRows(
        snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<ActivityRow, "id">) })),
      );
    });
    return () => unsub();
  }, [selected]);

  return (
    <div className="space-y-4">
      <div className="glass rounded-2xl p-3">
        <select
          value={selected}
          onChange={(e) => setSelected(e.target.value)}
          className="w-full bg-transparent outline-none text-sm px-2 py-1"
        >
          {users.map((u) => (
            <option key={u.uid} value={u.uid} className="bg-background">
              {u.username ?? u.email} — {(u.points ?? 0).toLocaleString()} XP
            </option>
          ))}
        </select>
      </div>

      <div className="glass rounded-2xl divide-y divide-white/5">
        {rows.length === 0 && (
          <div className="p-8 text-center text-muted-foreground text-sm">No activity yet.</div>
        )}
        {rows.map((r) => {
          const date = r.createdAt?.toDate?.();
          return (
            <div key={r.id} className="flex items-center gap-3 px-4 py-3">
              <div className="h-9 w-9 rounded-xl glass-strong flex items-center justify-center">
                <Sparkles className="h-4 w-4 text-brand-cyan" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium truncate">{actionLabel(r.action)}</div>
                <div className="text-[11px] text-muted-foreground">
                  {date ? date.toLocaleString() : "—"}
                </div>
              </div>
              <div className="text-brand-cyan text-sm font-semibold">+{r.points}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// -------------------- STATS --------------------

function StatsPanel() {
  const [stats, setStats] = useState({ users: 0, totalXp: 0, top: null as UserProfile | null });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const { db } = getFirebase();
    if (!db) return;
    (async () => {
      const snap = await getDocs(query(collection(db, "users"), orderBy("points", "desc")));
      const list = snap.docs.map((d) => d.data() as UserProfile);
      const totalXp = list.reduce((acc, u) => acc + (u.points ?? 0), 0);
      setStats({ users: list.length, totalXp, top: list[0] ?? null });
      setLoading(false);
    })().catch(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="glass rounded-2xl p-10 text-center">
        <Loader2 className="h-5 w-5 animate-spin inline text-brand-cyan" />
      </div>
    );
  }

  return (
    <div className="grid sm:grid-cols-3 gap-4">
      <StatTile icon={Users} label="Total Users" value={stats.users.toLocaleString()} />
      <StatTile icon={Sparkles} label="Total XP" value={stats.totalXp.toLocaleString()} />
      <StatTile
        icon={Trophy}
        label="Top User"
        value={stats.top?.username ?? "—"}
        sub={stats.top ? `${(stats.top.points ?? 0).toLocaleString()} XP` : undefined}
      />
    </div>
  );
}

function StatTile({
  icon: Icon,
  label,
  value,
  sub,
}: {
  icon: typeof Users;
  label: string;
  value: string;
  sub?: string;
}) {
  return (
    <div className="glass rounded-2xl p-5">
      <div className="flex items-center gap-3 mb-3">
        <div className="h-10 w-10 rounded-xl gradient-bg flex items-center justify-center glow">
          <Icon className="h-5 w-5 text-white" />
        </div>
        <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
      </div>
      <div className="text-2xl font-bold gradient-text">{value}</div>
      {sub && <div className="text-xs text-muted-foreground mt-1">{sub}</div>}
    </div>
  );
}
