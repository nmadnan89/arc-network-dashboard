import { Activity, Zap, Network, Users } from "lucide-react";

const stats = [
  { label: "Active Nodes", value: "12,847", icon: Network, trend: "+4.2%" },
  { label: "TPS", value: "2,940", icon: Zap, trend: "+12%" },
  { label: "Validators", value: "892", icon: Activity, trend: "+1.8%" },
  { label: "Wallets", value: "84.2K", icon: Users, trend: "+6.5%" },
];

export function EcosystemPulse() {
  return (
    <div className="glass rounded-2xl p-6 sm:p-7 relative overflow-hidden">
      <div className="absolute inset-0 opacity-30 pointer-events-none" style={{ background: "var(--gradient-glow)" }} />

      <div className="relative flex items-start justify-between mb-6 gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-brand-cyan uppercase tracking-[0.2em] mb-2">
            <span className="h-1.5 w-1.5 rounded-full bg-brand-cyan animate-pulse" />
            Ecosystem Pulse
          </div>
          <h2 className="text-xl sm:text-2xl font-semibold tracking-tight">The network is alive</h2>
          <p className="text-sm text-muted-foreground mt-1">Realtime activity across the ARC chain.</p>
        </div>

        {/* Animated network graphic */}
        <div className="hidden sm:block relative h-24 w-24 shrink-0">
          <svg viewBox="0 0 100 100" className="absolute inset-0">
            <defs>
              <linearGradient id="nodeGrad" x1="0" y1="0" x2="100" y2="100">
                <stop offset="0%" stopColor="#a78bfa" />
                <stop offset="100%" stopColor="#38bdf8" />
              </linearGradient>
            </defs>
            <line x1="50" y1="50" x2="15" y2="20" stroke="url(#nodeGrad)" strokeWidth="0.8" opacity="0.5" />
            <line x1="50" y1="50" x2="85" y2="20" stroke="url(#nodeGrad)" strokeWidth="0.8" opacity="0.5" />
            <line x1="50" y1="50" x2="15" y2="80" stroke="url(#nodeGrad)" strokeWidth="0.8" opacity="0.5" />
            <line x1="50" y1="50" x2="85" y2="80" stroke="url(#nodeGrad)" strokeWidth="0.8" opacity="0.5" />
            <line x1="50" y1="50" x2="50" y2="10" stroke="url(#nodeGrad)" strokeWidth="0.8" opacity="0.5" />
            <line x1="50" y1="50" x2="50" y2="90" stroke="url(#nodeGrad)" strokeWidth="0.8" opacity="0.5" />
            <circle cx="50" cy="50" r="6" fill="url(#nodeGrad)" />
            <circle cx="50" cy="50" r="10" fill="url(#nodeGrad)" opacity="0.2">
              <animate attributeName="r" from="6" to="14" dur="2s" repeatCount="indefinite" />
              <animate attributeName="opacity" from="0.6" to="0" dur="2s" repeatCount="indefinite" />
            </circle>
            {[
              { cx: 15, cy: 20 }, { cx: 85, cy: 20 }, { cx: 15, cy: 80 },
              { cx: 85, cy: 80 }, { cx: 50, cy: 10 }, { cx: 50, cy: 90 },
            ].map((p, i) => (
              <circle key={i} cx={p.cx} cy={p.cy} r="2.5" fill="#38bdf8">
                <animate attributeName="opacity" values="0.4;1;0.4" dur="2.5s" begin={`${i * 0.3}s`} repeatCount="indefinite" />
              </circle>
            ))}
          </svg>
        </div>
      </div>

      <div className="relative grid grid-cols-2 lg:grid-cols-4 gap-3">
        {stats.map((s, i) => (
          <div
            key={s.label}
            className="group glass-strong rounded-xl p-4 hover:-translate-y-0.5 transition-all animate-scale-in"
            style={{ animationDelay: `${i * 60}ms` }}
          >
            <div className="flex items-center justify-between mb-2">
              <s.icon className="h-4 w-4 text-brand-cyan" />
              <span className="text-[10px] text-emerald-400 font-mono">{s.trend}</span>
            </div>
            <div className="text-lg font-bold tracking-tight">{s.value}</div>
            <div className="text-[10px] text-muted-foreground uppercase tracking-wider mt-0.5">{s.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}