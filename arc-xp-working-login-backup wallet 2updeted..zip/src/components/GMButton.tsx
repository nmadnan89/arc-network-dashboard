import { useEffect, useState } from "react";
import { Sun, Loader2 } from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { claimGM, formatCountdown, nextGMTime } from "@/lib/gm";

export function GMButton() {
  const { user, profile } = useAuth();
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);

  const next = nextGMTime(profile?.lastGMClaim);
  const onCooldown = next !== null && next > now;
  const remaining = onCooldown ? next! - now : 0;
  const streak = (profile?.gmStreak as number | undefined) ?? 0;

  const onClaim = async () => {
    if (!user || onCooldown) return;
    setBusy(true);
    setErr(null);
    try {
      await claimGM(user.uid);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Claim failed");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="glass rounded-2xl p-5 sm:p-6 flex items-center justify-between gap-4 overflow-hidden relative">
      <div className="absolute -top-12 -right-12 h-40 w-40 rounded-full bg-yellow-400/20 blur-3xl pointer-events-none" />
      <div className="min-w-0">
        <div className="flex items-center gap-2 text-xs uppercase tracking-wider text-yellow-400/90">
          <Sun className="h-3.5 w-3.5" /> Daily GM
        </div>
        <div className="font-semibold mt-1">Say GM, earn +2 XP</div>
        <div className="text-xs text-muted-foreground mt-0.5">
          Streak: <span className="text-foreground font-medium">{streak}</span>
          {onCooldown && (
            <> · Next in <span className="font-mono text-brand-cyan">{formatCountdown(remaining)}</span></>
          )}
        </div>
        {err && <div className="text-xs text-red-400 mt-1">{err}</div>}
      </div>
      <button
        onClick={onClaim}
        disabled={!user || onCooldown || busy}
        className={`shrink-0 font-semibold px-4 sm:px-5 py-2.5 rounded-xl transition flex items-center gap-2 ${
          onCooldown
            ? "glass-strong text-muted-foreground cursor-not-allowed"
            : "gradient-bg text-primary-foreground glow hover:opacity-90"
        }`}
      >
        {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sun className="h-4 w-4" />}
        {onCooldown ? "Claimed" : "GM"}
      </button>
    </div>
  );
}
