import { createFileRoute } from "@tanstack/react-router";
import { Calendar, Users, Mic, Video, MessageCircle, Sparkles } from "lucide-react";
import { useState } from "react";
import { upcomingEvents } from "@/lib/demo-data";
import { useAuth } from "@/lib/auth-context";
import { awardXp } from "@/lib/xp";

export const Route = createFileRoute("/_app/events")({
  head: () => ({ meta: [{ title: "Events — ARC XP" }] }),
  component: Events,
});

const typeIcons: Record<string, typeof Mic> = {
  "Twitter Space": Mic,
  Webinar: Video,
  AMA: MessageCircle,
  Event: Sparkles,
};

function Events() {
  const [rsvped, setRsvped] = useState<number[]>([]);
  const { user } = useAuth();
  const toggle = async (id: number) => {
    setRsvped((p) => (p.includes(id) ? p.filter((x) => x !== id) : [...p, id]));
    if (user) {
      try {
        await awardXp(user.uid, "event_participation", `event:${id}`);
      } catch (e) {
        console.warn("award xp failed", e);
      }
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-3xl sm:text-4xl font-bold">
          <span className="gradient-text">Events</span>
        </h1>
        <p className="text-muted-foreground mt-1">Twitter Spaces, webinars, and community gatherings.</p>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {upcomingEvents.map((e, i) => {
          const Icon = typeIcons[e.type] ?? Calendar;
          const isRsvped = rsvped.includes(e.id);
          return (
            <div
              key={e.id}
              className="glass rounded-2xl p-5 flex flex-col gap-4 hover:scale-[1.02] transition animate-scale-in"
              style={{ animationDelay: `${i * 50}ms` }}
            >
              <div className="flex items-center justify-between">
                <div className="h-10 w-10 rounded-xl gradient-bg flex items-center justify-center glow">
                  <Icon className="h-5 w-5 text-white" />
                </div>
                <span className="text-xs px-3 py-1 rounded-full glass-strong">{e.type}</span>
              </div>
              <div>
                <h3 className="font-semibold text-lg leading-tight">{e.title}</h3>
                <p className="text-sm text-muted-foreground mt-1">Hosted by {e.host}</p>
              </div>
              <div className="text-sm text-brand-cyan flex items-center gap-2">
                <Calendar className="h-4 w-4" /> {e.date}
              </div>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Users className="h-3.5 w-3.5" /> {e.going.toLocaleString()} going
              </div>
              <button
                onClick={() => toggle(e.id)}
                className={`mt-auto py-2.5 rounded-xl text-sm font-semibold transition ${
                  isRsvped
                    ? "glass-strong text-brand-cyan ring-1 ring-brand-cyan/50"
                    : "gradient-bg text-primary-foreground glow hover:opacity-90"
                }`}
              >
                {isRsvped ? "✓ RSVP'd" : "RSVP"}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}