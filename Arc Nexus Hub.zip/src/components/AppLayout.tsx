import { Link, Outlet, useLocation } from "@tanstack/react-router";
import { LayoutDashboard, Trophy, Calendar, Award, User, Menu, X, Wallet } from "lucide-react";
import { useState } from "react";
import { ArcLogo } from "./ArcLogo";

const nav = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard },
  { to: "/leaderboard", label: "Leaderboard", icon: Trophy },
  { to: "/events", label: "Events", icon: Calendar },
  { to: "/badges", label: "Badges", icon: Award },
  { to: "/profile", label: "Profile", icon: User },
] as const;

export function AppLayout() {
  const location = useLocation();
  const [open, setOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col lg:flex-row relative">
      {/* Ambient gradient orbs */}
      <div aria-hidden className="pointer-events-none fixed inset-0 overflow-hidden -z-10">
        <div className="absolute -top-40 -left-40 h-[500px] w-[500px] rounded-full bg-brand-purple/30 blur-[120px] animate-orb" />
        <div className="absolute top-1/3 -right-40 h-[600px] w-[600px] rounded-full bg-brand-blue/25 blur-[140px] animate-orb" style={{ animationDelay: "-5s" }} />
        <div className="absolute bottom-0 left-1/3 h-[400px] w-[400px] rounded-full bg-brand-cyan/15 blur-[120px] animate-orb" style={{ animationDelay: "-10s" }} />
      </div>

      {/* Sidebar - desktop */}
      <aside className="hidden lg:flex lg:w-64 lg:flex-col lg:fixed lg:inset-y-0 z-30 p-4">
        <div className="glass rounded-2xl flex flex-col h-full p-5">
          <Brand />
          <nav className="mt-8 flex flex-col gap-1">
            {nav.map((item) => {
              const active = location.pathname === item.to;
              const Icon = item.icon;
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
                    active
                      ? "gradient-bg text-primary-foreground glow"
                      : "text-muted-foreground hover:text-foreground hover:bg-white/5"
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  {item.label}
                </Link>
              );
            })}
          </nav>
          <button className="mt-auto glass-strong rounded-xl p-4 text-left hover:bg-white/5 transition group">
            <div className="flex items-center gap-2.5 mb-1.5">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-cyan opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-brand-cyan" />
              </span>
              <span className="text-xs font-semibold gradient-text">ARC XP Mainnet</span>
            </div>
            <div className="flex items-center gap-2 text-xs">
              <Wallet className="h-3.5 w-3.5 text-muted-foreground" />
              <span className="font-mono text-foreground">0x4f...8e3a</span>
            </div>
            <div className="text-[10px] text-muted-foreground mt-1.5 uppercase tracking-wider">v2.6 · Block 19,284,012</div>
          </button>
        </div>
      </aside>

      {/* Topbar - mobile */}
      <header className="lg:hidden sticky top-0 z-40 glass m-3 rounded-2xl px-4 py-3 flex items-center justify-between">
        <Brand />
        <button onClick={() => setOpen(!open)} className="p-2 rounded-lg hover:bg-white/5">
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </header>
      {open && (
        <div className="lg:hidden mx-3 mb-3 glass rounded-2xl p-3 flex flex-col gap-1 animate-fade-in">
          {nav.map((item) => {
            const active = location.pathname === item.to;
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                onClick={() => setOpen(false)}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium ${
                  active ? "gradient-bg text-primary-foreground" : "hover:bg-white/5"
                }`}
              >
                <Icon className="h-4 w-4" />
                {item.label}
              </Link>
            );
          })}
        </div>
      )}

      <main className="flex-1 lg:ml-64 p-4 lg:p-10 relative">
        <Outlet />
      </main>
    </div>
  );
}

function Brand() {
  return (
    <Link to="/" className="flex items-center gap-3 group" aria-label="ARC XP">
      <div className="relative shrink-0">
        <ArcLogo size={34} className="relative z-10 transition-transform duration-500 group-hover:rotate-180" />
        <div className="absolute inset-0 bg-brand-purple/50 blur-xl rounded-full group-hover:bg-brand-cyan/40 transition-colors" />
      </div>
      <div className="flex flex-col leading-none">
        <div className="flex items-baseline gap-1.5">
          <span className="font-black text-lg tracking-[0.18em] gradient-text drop-shadow-[0_0_12px_rgba(167,139,250,0.45)]">
            ARC
          </span>
          <span className="h-3 w-px bg-gradient-to-b from-transparent via-brand-cyan to-transparent opacity-70" />
          <span className="font-light text-lg tracking-[0.32em] text-foreground/90">
            XP
          </span>
        </div>
        <div className="mt-1.5 flex items-center gap-1.5">
          <span className="h-px w-3 bg-gradient-to-r from-brand-purple to-brand-cyan" />
          <span className="text-[9px] text-muted-foreground tracking-[0.35em] uppercase font-medium">
            Protocol
          </span>
        </div>
      </div>
    </Link>
  );
}